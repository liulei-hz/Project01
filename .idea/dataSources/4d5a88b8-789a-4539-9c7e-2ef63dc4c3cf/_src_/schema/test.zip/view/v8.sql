CREATE VIEW v8 AS
  SELECT
    `test`.`students`.`id`       AS `id`,
    `test`.`students`.`userName` AS `userName`,
    `test`.`students`.`money`    AS `money`
  FROM `test`.`students`;
