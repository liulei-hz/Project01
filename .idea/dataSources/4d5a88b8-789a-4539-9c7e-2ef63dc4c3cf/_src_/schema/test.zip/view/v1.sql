CREATE VIEW v1 AS
  SELECT
    `o`.`four_code`  AS `four_code`,
    `o`.`dataSource` AS `dataSource`
  FROM (`test`.`material` `m`
    JOIN `test`.`materialinfo` `o` ON ((`m`.`materialName` = `o`.`materialName`)));
