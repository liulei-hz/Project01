CREATE VIEW v2 AS
  SELECT `o`.`four_code` AS `four_code`
  FROM (`test`.`material` `m`
    JOIN `test`.`materialinfo` `o` ON ((`m`.`materialName` = `o`.`materialName`)));
